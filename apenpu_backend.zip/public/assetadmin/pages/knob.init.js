/*
 Template Name: Veltrix - Responsive Bootstrap 4 Admin Dashboard
 Author: Themesbrand
 File: Knob Init
*/

$(function() {
    $(".knob").knob({
    });
});